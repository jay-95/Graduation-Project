# What Are these Files?

The .sch and .brd files hare are Eagle CAD schematic and PCB design files.

These files were created with Eagle 6.5.0, you'll need Eagle 6.5 or later to open them up. There is a free, lite, version of Eagle available from [cadsoftusa.com](cadsoftusa.com).

# License

This product is open source! These Eagle files are released under the Creative Commons Share-Alike Attribution license ([CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/us/)).

Please use, reuse, and modify these files as you see fit. Please maintain attribution and release anything derivative under the same license.

- Your friends at SparkFun.